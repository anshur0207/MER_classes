There are two databases

1)merclasses
-> contact_table (for contact form)
2)phplearning
->users for login and signip